# College Website
### Welcome to the new official website project of VCET Ongole. 

[![Join the chat at https://gitter.im/VCET/college_website](https://badges.gitter.im/VCET/college_website.svg)](https://gitter.im/VCET/college_website?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

We are now live as [official institute website](http://VCETOngole.ac.in/).

**NOTE**: This repository is no longer related to the live college website, therefore the requests made here for content addition/modifiation are ineffective.


#### Navigation Scheme
* Institute
    * About
    * Director's Message
    * Board of Governors
    * Society Members
    * Academic Council
    * Finance Committee
    * RTI
    * MOU
    * Linkages
        * VCET
        * GSFC
        * GERMI
        * TCS
* Academics
    * Bachelor of Technology
        * Mechanical Engineering
        * Information Technology
    * Master of Technology
        * Mechanical Engineering
    * Doctor of Philosophy
    * Academic Calender
* Admissions
    * Bachelor of Technology
    * Master of Technology
    * Doctor of Philosophy
* People
    * Faculty
    * Visiting Faculty
    * Staff
* More
    * FAQs
    * Students' Corner
    * Moodle
    * Library
    * Invited Talks
* Career
* Photo Gallery


#### Thanks.

